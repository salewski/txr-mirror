/*
    mplogic.h

    by Michael J. Fromberger <http://www.dartmouth.edu/~sting/>
    Copyright (C) 1998 Michael J. Fromberger, All Rights Reserved

    Bitwise logical operations on MPI values

    $Id: mplogic.h,v 1.1 2004/02/08 04:29:29 sting Exp $
 */

#ifndef _H_MPLOGIC_
#define _H_MPLOGIC_

#include "mpi.h"

/*
  The logical operations treat an mp_int as if it were a bit vector,
  without regard to its sign (an mp_int is represented in a signed
  magnitude format).  Values are treated as if they had an infinite
  string of zeros left of the most-significant bit.
 */

/* Parity results                    */

#define MP_EVEN       MP_YES
#define MP_ODD        MP_NO

/* Bitwise functions                 */

mp_err mpl_not(mp_int *a, mp_int *b);            /* one's complement  */
mp_err mpl_and(mp_int *a, mp_int *b, mp_int *c); /* bitwise AND       */
mp_err mpl_or(mp_int *a, mp_int *b, mp_int *c);  /* bitwise OR        */
mp_err mpl_xor(mp_int *a, mp_int *b, mp_int *c); /* bitwise XOR       */

/* Shift functions                   */

mp_err mpl_rsh(mp_int *a, mp_int *b, mp_digit d);   /* right shift    */
mp_err mpl_lsh(mp_int *a, mp_int *b, mp_digit d);   /* left shift     */

/* Bit count and parity              */

mp_err mpl_num_set(mp_int *a, int *num);         /* count set bits    */
mp_err mpl_num_clear(mp_int *a, int *num);       /* count clear bits  */
mp_err mpl_parity(mp_int *a);                    /* determine parity  */

#endif /* end _H_MPLOGIC_ */
